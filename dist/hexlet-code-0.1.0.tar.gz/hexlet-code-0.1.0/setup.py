# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'five mini games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/zub41k/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/zub41k/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/6da4fd6d2c482686c96c/maintainability)](https://codeclimate.com/github/zub41k/python-project-49/maintainability)\n\nInstructions for installing and running the minigames\n\nClone the repository\n    git clone https://github.com/zub41k/python-project-49.git\n\nmake install\n    poetry install\n\nmake build\n    poetry build\n\nmake publish\n    poetry publish --dry-run\n\nmake package-install\n    python3 -m pip install --user --force-reinstall  dist/*.whl\n\nBRAIN-EVEN\nhttps://asciinema.org/a/U7er5eLUONKmMxTinFJmuNFTd\n\nBRAIN-CALC\nhttps://asciinema.org/connect/cf987227-5292-4e78-a36f-ceea6e17652f\n\nBRAIN-GCD\nhttps://asciinema.org/a/7FUw7phClsg2leA4OWWSCQ5mQ\n\nBRAIN-PROGRESSION\nhttps://asciinema.org/a/5bynFnGJ8cwS8WeBMDU0snVbd\n\nBRAIN-PRIME\nhttps://asciinema.org/a/m6jvksI2ZNtJfK2g5BhlZFMHR\n',
    'author': 'Юрий',
    'author_email': 'zub-69-z@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/zub41k/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
