### Hexlet tests and linter status:
[![Actions Status](https://github.com/zub41k/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/zub41k/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/6da4fd6d2c482686c96c/maintainability)](https://codeclimate.com/github/zub41k/python-project-49/maintainability)
