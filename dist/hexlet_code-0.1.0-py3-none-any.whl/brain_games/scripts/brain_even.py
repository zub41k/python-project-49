#!/usr/bin/env python3

from brain_games.game import checking_num


def main():
    checking_num()


if __name__ == '__main__':
    main()
